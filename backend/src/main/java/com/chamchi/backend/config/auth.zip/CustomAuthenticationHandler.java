package com.chamchi.backend.config.auth;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.NoArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

@Component
@NoArgsConstructor
public class CustomAuthenticationHandler implements AuthenticationSuccessHandler {
//    private Boolean isLoginSuccess;
    private static final String REDIRECT_URI = "http://localhost:3000/login/callback";

    private OAuth2AuthorizedClientService oAuth2AuthorizedClientService;

    /*public CustomAuthenticationHandler(Boolean isLoginSuccess) {
        this.isLoginSuccess = isLoginSuccess;
    }*/

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        Object principal = authentication.getPrincipal();
        if (principal instanceof OAuth2User oAuth2User) {
            Map<String, Object> attributes = oAuth2User.getAttributes();

            String redirectUri = UriComponentsBuilder.fromUriString(REDIRECT_URI)
                    .queryParam("accessToken", attributes.get("accessToken"))
//                    .queryParam("refreshToken", "refreshToken")
                    .build()
                    .encode(StandardCharsets.UTF_8)
                    .toUriString();

            response.sendRedirect(redirectUri);
        }
    }
}
