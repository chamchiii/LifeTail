package com.chamchi.backend.config.auth.dto;

import com.chamchi.backend.domain.users.Users;
import com.chamchi.backend.util.Provider;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserProfile {
    private String name;
    private String email;
    private String provider;
    private String userId;

    public Users toUsers(){
        return Users.builder().name(name).email(email).build();
    }

    @Override
    public String toString() {
        return "UserProfile{" +
                "name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", provider='" + provider + '\'' +
                ", userId='" + userId + '\'' +
                '}';
    }
}
