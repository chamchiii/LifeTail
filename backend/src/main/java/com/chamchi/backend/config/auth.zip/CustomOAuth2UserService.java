package com.chamchi.backend.config.auth;

import com.chamchi.backend.config.auth.dto.OAuthAttributes;
import com.chamchi.backend.config.auth.dto.UserProfile;
import com.chamchi.backend.domain.users.Users;
import com.chamchi.backend.repository.users.UsersRepository;
import com.chamchi.backend.util.Provider;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class CustomOAuth2UserService implements OAuth2UserService<OAuth2UserRequest, OAuth2User> {
    private final UsersRepository usersRepository;
    private final HttpSession httpSession;

    @Override
    public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
        OAuth2UserService<OAuth2UserRequest, OAuth2User> delegate = new DefaultOAuth2UserService();
        OAuth2User oAuth2User = delegate.loadUser(userRequest);

        System.out.println(userRequest.getAccessToken().getTokenValue());

        //현재 진행중인 서비스를 구분 - 구글, 네이버, 카카오 등등
        String registrationId = userRequest.getClientRegistration().getRegistrationId();
        String userNameAttributeName = userRequest.getClientRegistration().getProviderDetails().getUserInfoEndpoint().getUserNameAttributeName();

        Map<String, Object> attributes = oAuth2User.getAttributes();

        UserProfile userProfile = com.chamchi.backend.config.auth.OAuthAttributes.extract(registrationId, attributes);
        userProfile.setProvider(registrationId);

        Users users = saveOrUpdate(userProfile);

        Map<String, Object> customAttribute = customAttribute(attributes, userNameAttributeName, userProfile, registrationId, userRequest.getAccessToken().getTokenValue());


        return new DefaultOAuth2User(
                Collections.singleton(new SimpleGrantedAuthority(users.getRole().getKey())),
                customAttribute,
                userNameAttributeName
        );
        /*OAuthAttributes attributes = OAuthAttributes.of(registrationId, userNameAttributeName, oAuth2User.getAttributes());

        Users users = saveOrUpdate(attributes);

        httpSession.setAttribute("user", new SessionUser(users));

        return new DefaultOAuth2User(Collections.singleton(new SimpleGrantedAuthority(users.getRoleKey())),
                attributes.getAttributes(),
                attributes.getNameAttributeKey());*/
    }

    private Map customAttribute(Map attributes, String userNameAttributeName, UserProfile userProfile, String registrationId, String oAuth2AccessToken) {
        Map<String, Object> customAttribute = new LinkedHashMap<>();
        customAttribute.put(userNameAttributeName, attributes.get(userNameAttributeName));
        customAttribute.put("provider", registrationId);
        customAttribute.put("name", userProfile.getName());
        customAttribute.put("email", userProfile.getEmail());
        customAttribute.put("accessToken", oAuth2AccessToken);
        return customAttribute;
    }

    private Users saveOrUpdate(UserProfile userProfile){
        Users users = usersRepository.findByEmailAndProvider(userProfile.getEmail(), userProfile.getProvider())
                .map(item -> item.update(userProfile.getName(), userProfile.getEmail())).orElse(userProfile.toUsers());
        return usersRepository.save(users);
    }
    /*private Users saveOrUpdate(OAuthAttributes attributes) {
        Users users = usersRepository.findByEmailAndProvider(attributes.getEmail(), String.valueOf(Provider.Google.getKey()))
                .map(entity -> entity.update(attributes.getName(), attributes.getEmail()))
                .orElse(attributes.toEntity());

        return usersRepository.save(users);
    }*/
}
